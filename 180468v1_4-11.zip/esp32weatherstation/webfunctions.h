#ifndef WEBFUNCTION_H_
#define WEBFUNCTION_H_
#include <WebServer.h>

void register_functions ( WebServer* webserver );


#endif
